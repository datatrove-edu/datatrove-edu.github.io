# Movie genre counts by year (1950–2025)

Counts of films per genre per year, derived from Wikidata.

**Source:** Wikidata (https://www.wikidata.org), queried via SPARQL.  
**License:** CC0 1.0 (public domain) — free to host, redistribute, and modify, no attribution required.  
**Scope:** films (`wd:Q11424`) with a publication date (`P577`) and a genre (`P136`), counting distinct films per genre per year.

## Files

- One CSV per genre (e.g. `drama.csv`), columns `year,count`, with every year 1950–2025 present (zeros where no films).
- `all_genres_long.csv` — `genre,year,count`.
- `all_genres_wide.csv` — `year` plus one column per genre.
- `exponential_fit_parameters_1980_2014.csv` — fitted `A`, `k`, %/yr, doubling time, and R² for `N(t) = A·e^{k t}` with `t = year − 1980`.
- `query.sparql` — the exact query used to produce the counts.

## Genre mapping

Each broad genre maps to a single canonical Wikidata genre label, with no sub-genre merging; a film is counted once per genre it is tagged with.

| Display name | Wikidata label | Total films 1950–2025 | File |
|---|---|---:|---|
| Drama | `drama film` | 68,200 | `drama.csv` |
| Comedy | `comedy film` | 32,326 | `comedy.csv` |
| Documentary | `documentary film` | 32,756 | `documentary.csv` |
| Action | `action film` | 12,482 | `action.csv` |
| Thriller | `thriller film` | 10,477 | `thriller.csv` |
| Horror | `horror film` | 10,094 | `horror.csv` |
| Crime | `crime film` | 8,601 | `crime.csv` |
| Romance | `romance film` | 9,063 | `romance.csv` |
| Adventure | `adventure film` | 5,764 | `adventure.csv` |
| Science Fiction | `science fiction film` | 4,809 | `science_fiction.csv` |
| Biography | `biographical film` | 4,874 | `biography.csv` |
| Fantasy | `fantasy film` | 4,121 | `fantasy.csv` |
| Musical | `musical film` | 4,578 | `musical.csv` |
| War | `war film` | 3,703 | `war.csv` |
| Mystery | `mystery film` | 2,629 | `mystery.csv` |
| History | `historical film` | 2,815 | `history.csv` |
| Western | `Western film` | 2,242 | `western.csv` |
| Family | `family film` | 1,937 | `family.csv` |

## Adult and exploitation films

Films whose Wikidata genres include adult or exploitation categories are excluded from these counts. Wikidata catalogues such films in large numbers and frequently cross-tags them into mainstream genres (drama, comedy, action, crime), where they would otherwise distort the per-genre yearly counts. A film is dropped if it carries any of the following genres, even when it also carries a mainstream genre:

`erotic film`, `pornographic film`, `sex film`, `exploitation film`, `sexploitation film`, `erotic thriller`, `erotic thriller film`, `blaxploitation film`, `pink film`, `pornographic parody film`, `Bavarian porn`, `softcore pornography`, `lesbian pornographic film`, `gay pornographic film`, `Nazi exploitation`, `erotic drama film`, `erotica`, `gonzo pornography`, `comedy porn film`, `MILF pornography`.

This list includes `exploitation film` and `blaxploitation film`, which cover some legitimate low-budget genre cinema as well as adult content; narrow the list to the pornographic/erotic terms to retain those.

## Notes on coverage

- Counts are conservative; Wikidata catalogues a subset of all films released, with thinner coverage of recent low-budget and international titles.
- The most recent years (about 2024–2025) are still being added to Wikidata and read artificially low.
- The dip around 2020 reflects the COVID-19 production slowdown.